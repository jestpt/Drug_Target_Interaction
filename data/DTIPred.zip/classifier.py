print("Loading libraries...")
import numpy as np
import pandas as pd
import time
from pandas import DataFrame
from operator import itemgetter
from sklearn.preprocessing import Imputer, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier as RF
from sklearn.ensemble import AdaBoostClassifier as AB
from sklearn.cross_validation import cross_val_score as CV
from sklearn.cross_validation import StratifiedShuffleSplit
from sklearn.metrics import confusion_matrix
from sklearn import metrics, preprocessing, dummy

def dataset_splitter():

    start = time.time()
    print("Loading data...")
    ### Open/parse files ###
    train = pd.read_csv('yamanishi_DTIs_REAL_NEGS.txt', sep='\t', header=None)
    drugbank = pd.read_csv('drugbank_DTIs_REAL_NEGS.txt', sep='\t', header=None)
    test = pd.read_csv('test_data_sc_and_bc.txt', sep='\t', header=None)

    return start, train, drugbank, test
    
def classifier(train, drugbank, test, logfilename):

    logfile = open(logfilename, 'wt')

    ### Extract targets and classes for train and test data ###
    print("Preprocessing data...")

    print 'Full Yamanishi: ', train.shape # 18118
    train_y = train.ix[:,2]
    train = train.iloc[:,3:]
    train = train.drop_duplicates()
    train_y = train_y.loc[train.index]
    print 'Yamanishi no-duplicates:', train.shape # 16802

    print 'Full DrugBank: ', drugbank.shape # 8827
    drugbank_y = drugbank.ix[:,2]
    drugbank = drugbank.iloc[:,3:]
    drugbank = drugbank.drop_duplicates()
    drugbank_y = drugbank_y.loc[drugbank.index]
    print 'DrugBank no-duplicates: ', drugbank.shape # 8529

    print 'Full Test: ', test.shape # 31020
    test = test.dropna()
    test_labels = test.iloc[:,:2]
    test_labels.columns = ["Protein ID", "Drug ID"]
    test = test.iloc[:,2:]
    test = test.drop_duplicates()
    test_labels = test_labels.loc[test.index]
    print 'Test no-duplicates: ', test.shape # 30810

    ### Normalization and scaling steps ###
    scaler = MinMaxScaler(feature_range=(-1,1))

    train = preprocessing.normalize(train)
    drugbank = preprocessing.normalize(drugbank)
    test = preprocessing.normalize(test)

    # train = scaler.fit_transform(train)
    # drugbank = scaler.transform(drugbank)
    # test = scaler.transform(test)

    ### Cross Validation parameters ###
    state = 'y' # 'y' to perform cross validation, anything else to skip
    n_folds = 5 # desired number of folds
    n_features = 100

    if state == 'y':
        ### Construct and fit classifiers ###
        forest = RF(n_estimators = 150, max_features = n_features, n_jobs = -1, max_depth = None, oob_score = True)
        elapsed = time.time() - start
        print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")
        print('\nCross-validating classification with ' + str(n_folds) + ' folds...')
        elapsed = time.time() - start
        print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")
        scores = CV(forest, train, train_y, cv=n_folds, n_jobs=-1, scoring='roc_auc')
        print("CV Scores: ")
        for i in scores:
            print i
        print('RF Cross-validation AUC: %0.2f (+/- %0.2f)' % (scores.mean(), scores.std() * 2))
        elapsed = time.time() - start
        print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")
        logfile.write('RF CROSS-VALIDATION RESULTS (' + str(n_folds) + ' folds):\n')
        logfile.write('AUC: %0.2f (+/- %0.2f)\n' % (scores.mean(), scores.std() * 2))
        print("\nFitting Classifiers...")
        forest = forest.fit(train, train_y)
    else:
        ### Construct and fit classifiers ###
        forest = RF(n_estimators = 150, max_features = n_features, n_jobs = -1, max_depth = None, oob_score = True)
        elapsed = time.time() - start
        print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")
        print("Fitting Classifiers...")
        forest = forest.fit(train, train_y)
        print forest.score(train, train_y)
        logfile.write('RF training score: %s\n\n' % (forest.score(train, train_y)))
        # dummy_clf = dummy.DummyClassifier(strategy='stratified')
        # dummy_clf = dummy_clf.fit(train, train_y)
        elapsed = time.time() - start
        print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")

    ### Calculate feature importances ###
    # importances = forest.feature_importances_

    # cols_importance_pairs = zip(train_cols, importances)
    # sorted_pairs = sorted(cols_importance_pairs, key = itemgetter(1), reverse=True)
    # sorted_pairs = sorted_pairs[:n_features]
    # print sorted_pairs

    ### Perform predictions on external validation data ###
    print('\nClassifying external validation set...')
    elapsed = time.time() - start
    print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")

    rf_drugbank_pred = forest.predict(drugbank)

    fpr, tpr, thresholds = metrics.roc_curve(drugbank_y, rf_drugbank_pred, pos_label=1)
    cm = confusion_matrix(drugbank_y, rf_drugbank_pred)
    auc = metrics.auc(fpr, tpr)

    print('\nRF DrugBank EXTERNAL VALIDATION RESULTS\nAUC: %s\n' % auc)
    print(cm)
    logfile.write('\n\nRF DrugBank EXTERNAL VALIDATION RESULTS:\nAUC: %s\n' % (auc))
    logfile.write('CONFUSION MATRIX:\n %s' % (cm))

    logfile.close()

    ### Perform predictions on test data ###
    print('\nClassifying external validation set...')
    elapsed = time.time() - start
    print("\nTime elapsed: " + str(int(elapsed/60)) + " minutes.")

    test_data_pred = forest.predict_proba(test)

    test_labels['RF predictions'] = test_data_pred[:,1]
    test_labels.to_csv('test_data_predictions.txt', sep='\t', header=False, index=False)

if __name__ == '__main__':
    start, train, drugbank, test = dataset_splitter()
    classifier(train, drugbank, test, 'rf_yama_train_drugbank_ext_val_mrsa_test_log.txt')
